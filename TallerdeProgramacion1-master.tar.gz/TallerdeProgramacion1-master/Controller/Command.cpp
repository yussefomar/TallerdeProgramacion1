#include "Command.h"

Command::Command()
{
    //ctor
}

Command::~Command()
{
    //dtor
}
