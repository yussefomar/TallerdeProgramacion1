#include "Model_Equipo.h"

Equipo::Equipo()
{

}
int Equipo::agregarJugador(Jugador jugador)
{
    return 0;
}

