#ifndef FORMACION321_H
#define FORMACION321_H

#include <Formacion.h>


class Formacion321 : public Formacion
{
    public:
        Formacion321();
        virtual ~Formacion321();
        void setPosicionInicial(Jugador* jugadores);

    protected:

    private:
};

#endif // FORMACION321_H
