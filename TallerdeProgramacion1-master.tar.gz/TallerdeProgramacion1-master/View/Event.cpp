#include "Event.h"

Event::Event()
{
    //ctor
}

Event::~Event()
{
    //dtor
}
