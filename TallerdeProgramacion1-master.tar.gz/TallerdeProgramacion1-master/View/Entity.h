#ifndef ENTITY_H
#define ENTITY_H


class Entity
{
    public:
        Entity();
        virtual ~Entity();

    protected:

    private:
};

#endif // ENTITY_H
